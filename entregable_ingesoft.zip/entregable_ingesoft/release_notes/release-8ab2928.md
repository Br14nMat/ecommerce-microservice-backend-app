
                            # Release Notes - 8ab2928

                            **Fecha y hora:** 2025-05-29 21:30:00  
                            **Ambiente:** prod  

                            ## ? Cambios recientes
                            - another fix (Br14nMat)
                            - fix payment manifiest (Br14nMat)

                            ## ? Resultados esperados
                            - Pruebas unitarias e integradas: ? OK
                            - Pruebas E2E: ? OK 
                            - Pruebas de carga Locust: ? OK (ver Newman report) 
                                - Archivos: locust_output/*/locust_report.html

                            ## ? Referencia
                            - Build: #54
                            - Commit: 8ab2928
                            - Branch: master
                            